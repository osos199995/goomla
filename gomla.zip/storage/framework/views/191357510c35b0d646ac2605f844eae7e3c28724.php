
<?php $__env->startSection('content'); ?>


    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">

                <h2> تفاصيل الطلب </h2>
                <ul class="nav navbar-right panel_toolbox">
                    

                </ul>
                <div class="clearfix"></div>
            </div>

            <div class="x_content">

                <table class="table table-striped">
                    <thead class="thead-light">
                        <tr>
                            <th>#</th>
                            <th>اسم المنتج</th>
                            <th> سعر المنتج </th>
                            <th>  الكميه المطلوبه </th>
                            
                        </tr>
                    </thead>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       
                        <tbody>
                          <tr>
                              <th scope="row"><?php echo e(++$i); ?></th>
                              <td><?php echo e($order->product->name); ?></td>
                              <td><?php echo e($order->price); ?></td>
                              <td><?php echo e($order->quantity); ?></td>
                              
                          </tr>
                        </tbody>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(url('admin/orders/' . $first->id . '/mandobs')); ?>" class="btn btn-success" style="float: right">
                            <i class="fa fa-user"></i>
                        </a>
                        <a href="<?php echo e(url('admin/orders/' . $first->id . '/track')); ?>" class="btn btn-success" style="float: right">
                            <i class="fa fa-motorcycle"></i>
                        </a>
                </table>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/vfffgsmy/public_html/control/resources/views/admin/orders/show.blade.php ENDPATH**/ ?>