
<?php $__env->startSection('content'); ?>


<div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
        <div class="x_title">
        
          <h2>  المديونيات </h2>
          <ul class="nav navbar-right panel_toolbox">
            
            </li>
            
          </ul>
          <div class="clearfix"></div>
        </div>
        
        <div class="x_content">
        
          <table class="table table-striped">
            <thead  class="thead-light">
              <tr>
              <th>#</th>
              <th> اسم المستخدم </th>
              
              <th width="15%">التحكم</th>
              
            </tr>
          </thead>
          <tbody>
          <?php $__currentLoopData = $depts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
            <tr>  
                <th scope="row"><?php echo e(++$i); ?></th> 
                <td><?php echo e($dept->user->name); ?></td>
                
               
                
              
                <td>
                <a href="<?php echo e(url('admin/depts/'.$dept['user_id'])); ?>" class="btn btn-success" >
                  <i class="fa fa-eye"></i>
                 </a>
              
                
        
               </td>
        
              </tr>
        
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            </tbody>
          </table>
        
        </div>
        </div>
        </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/vfffgsmy/public_html/control/resources/views/admin/depts/index.blade.php ENDPATH**/ ?>