
<?php $__env->startSection('content'); ?>


<div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
        <div class="x_title">
        
          <h2>  المستخدمين </h2>
          
          <div class="clearfix"></div>
        </div>
        
        <div class="x_content">
        
          <table class="table table-striped">
            <thead  class="thead-light">
              <tr>
              <th>#</th>
              <th>اسم المستخدم</th>
              <th> البريد الالكتروني</th>
              <th> رقم التليفون</th>
              
              <th width="15%">التحكم</th>
              
            </tr>
          </thead>
          <tbody>
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
            <tr>  
                <th scope="row"><?php echo e(++$i); ?></th> 
                <td><?php echo e($user['name']); ?></td>
                <td><?php echo e($user['email']); ?></td>
                <td><?php echo e($user['id']); ?></td>
               
                
              
                <td>
              
              

                 <form method="POST" onclick="return confirm('Are you sure?')" action="<?php echo e(url('admin/users/'.$user['id'])); ?>"  style="display:inline" >
                
                <button name="_method" type="hidden" value="DELETE" class="btn btn-default btn-sm">
                <span class="glyphicon glyphicon-remove"></span>
                </button>
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                </form>
        
               </td>
        
        
           
                 
              </tr>
        
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            </tbody>
          </table>
        
        </div>
        </div>
        </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mostafa/meeza.innovations-eg.com/resources/views/admin/users/index.blade.php ENDPATH**/ ?>