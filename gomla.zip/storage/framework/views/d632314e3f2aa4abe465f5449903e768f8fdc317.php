
<?php $__env->startSection('content'); ?>


<div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
        <div class="x_title">
        
          <h2>  شكاوي المنتج</h2>
         
          <div class="clearfix"></div>
        </div>
        
        <div class="x_content">
        
          <table class="table table-striped">
            <thead  class="thead-light">
              <tr>
              <th>#</th>
              <th>اسم اليوزر</th>
              <th>  اسم المنتج  </th>
              <th>الشكوي  </th>
              
              <th width="15%">التحكم</th>
              
            </tr>
          </thead>
          <tbody>
          <?php $__currentLoopData = $complaintsproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$complaint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
            <tr>  
                <th scope="row"><?php echo e(++$i); ?></th> 
                <td><?php echo e($complaint->user->name); ?></td>
                <td><?php echo e($complaint->product->name); ?></td>
                <td><?php echo e($complaint->comment); ?></td>
               
                
              
                <td>
                

                 <form method="POST" onclick="return confirm('Are you sure?')" action="<?php echo e(url('admin/complaintsproducts/'.$complaint['id'])); ?>"  style="display:inline" >
                
                <button name="_method" type="hidden" value="DELETE" class="btn btn-default btn-sm">
                <span class="glyphicon glyphicon-remove"></span>
                </button>
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                </form>
        
               </td>
        
        
           
                 
              </tr>
        
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            </tbody>
          </table>
        
        </div>
        </div>
        </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mostafa/meeza.innovations-eg.com/resources/views/admin/complaintsproducts/index.blade.php ENDPATH**/ ?>