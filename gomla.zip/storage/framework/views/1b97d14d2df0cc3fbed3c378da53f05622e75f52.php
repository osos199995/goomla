

<?php $__env->startSection('content'); ?>



        <div class="page-title">
            <div class="title_left" style="float: right;direction: rtl;">
                <h3 >الصفحه الشخصيه</h3>
            </div>

            
        </div>

        <div class="clearfix"></div>

        <div class="row" style="direction: rtl">
            <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                    <div class="x_title">
                        
                        <ul class="nav navbar-right panel_toolbox">
                            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                            </li>
                            <li class="dropdown">
                                
                               
                            </li>
                            
                        </ul>
                        
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <div class="col-md-12 col-sm-12  profile_left">
                            <div class="profile_img">
                                <div id="crop-avatar">
                                    <!-- Current avatar -->
                                    <?php if($users->image): ?>
                                    <img class="img-responsive avatar-view" src="<?php echo e(url('/')); ?>/public/images/user1.png" alt="Avatar"
                                        title="Change the avatar" style="float:right;width: 250px;height: 250px;border-radius: 110px;">
                                    <?php else: ?>
                                    <img class="img-responsive avatar-view" src="<?php echo e(url('/')); ?>/public/images/picture.jpg" alt="Avatar"
                                        title="Change the avatar" style="float:right;width: 250px;height: 250px;border-radius: 110px;">
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div style="text-align:center">
                            <h3><?php echo e($users->name); ?> </h3>
                           


                            <ul class="list-unstyled user_data">
                            <?php if($users->shop_name): ?>
                                <li style="font-size: 18px;">
                                    <i class="fa fa-map-marker user-profile-icon"></i>

                                    <label>   اسم المحل</label>
                                     <?php echo e($users->shop_name); ?>  
                                    
                                </li>
                            <?php endif; ?>
                            <?php if($users->shop_type): ?>
                            <li style="font-size: 18px;">
                                <i class="fa fa-map-marker user-profile-icon"></i>
                                <label> نوع المحل</label>
                                 <?php echo e($users->shop_type); ?>  
                            </li>
                            <?php endif; ?>
                            <?php if($users->address): ?>
                            <li style="font-size: 18px;">
                                <i class="fa fa-map-marker user-profile-icon"></i>
                                <label>  العنوان</label>
                                 <?php echo e($users->address); ?>  
                            </li>
                            <?php endif; ?>
                            <?php if($users->area): ?>
                            <li style="font-size: 18px;">
                                <i class="fa fa-map-marker user-profile-icon"></i>
                                <label>  المنطقه </label>
                                 <?php echo e($users->area); ?>  
                            </li>
                            <?php endif; ?>
                               

                              
                            </ul>

                            
                            <br />


                        </div>
                    </div>
                       
                    </div>
                </div>
            </div>
        </div>
 

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/vfffgsmy/public_html/control/resources/views/admin/users/show.blade.php ENDPATH**/ ?>