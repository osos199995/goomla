
<?php $__env->startSection('content'); ?>


<div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_panel">
            <div class="x_title">
              <h2>تعديل المنتج</h2>
              <ul class="nav navbar-right panel_toolbox">
                <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                </li>
                
        </ul>
        <div class="clearfix"></div>
      </div>
      <div class="x_content">
        <br>
        <form method="POST" action="<?php echo e(url('admin/products/'.$products->id)); ?>" enctype="multipart/form-data" categories-parsley-validate="" class="form-horizontal form-label-left" >
        
        <input name="_method" type="hidden" value="PUT">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="category_id">اسم المخزن
              </label>
              <div class="col-md-6 col-sm-6 col-xs-12">
                <select class="form-control" required id="exampleFormControlSelect1" class="form-control col-md-6 col-xs-12" name="store_id">
                  <option value="">---</option>
                  
                  <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($store->id); ?>" <?php echo e(($store->id == $products->store_id)?"selected":""); ?>><?php echo e($store->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
     
                </select>
              </div>
            </div>

            <div class="form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="category_id">اسم الفئه
              </label>
              <div class="col-md-6 col-sm-6 col-xs-12">
                <select class="form-control" required id="exampleFormControlSelect1" class="form-control col-md-6 col-xs-12" name="category_id">
                  <option value="">---</option>
                  
                  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>" <?php echo e(($category->id == $products->category_id)?"selected":""); ?>><?php echo e($category->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
     
                </select>
              </div>
            </div>

            <div class="form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="category_id">اسم الفئه الفرعية
              </label>
              <div class="col-md-6 col-sm-6 col-xs-12">
                <select class="form-control" required id="exampleFormControlSelect1" class="form-control col-md-6 col-xs-12" name="subcategory_id">
                  <option value="">---</option>
                  
                  <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>" <?php echo e(($category->id == $products->subcategory_id)?"selected":""); ?>><?php echo e($category->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
     
                </select>
              </div>
            </div>
            
            <div class="form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="category_id">اسم الشركة
              </label>
              <div class="col-md-6 col-sm-6 col-xs-12">
                <select class="form-control" id="exampleFormControlSelect1" class="form-control col-md-6 col-xs-12" name="company_id">
                  <option value="">---</option>
                  
                  <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($company->id); ?>" <?php echo e(($company->id == $products->company_id)?"selected":""); ?>><?php echo e($company->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
     
                </select>
              </div>
            </div>
             

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"> اسم المنتج  <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input  type="text"  name="name" id="name" value="<?php echo e($products->name); ?>" class="form-control col-md-7 col-xs-12" required>
                        </div>
                      </div>

                      
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"> نوع الوحدة
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input  type="text"  name="unit_type" id="unit_type" value="<?php echo e($products->unit_type); ?>" class="form-control col-md-7 col-xs-12" >
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"> نوع القطعه الواحده
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input  type="text"  name="subunit_type" id="subunit_type" value="<?php echo e($products->subunit_type); ?>" class="form-control col-md-7 col-xs-12" >
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="quantity_unit"> كمية الوحده
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input  type="number"  name="quantity_unit" id="quantity_unit" value="<?php echo e($products->quantity_unit); ?>" class="form-control col-md-7 col-xs-12" >
                        </div>
                      </div>

                      
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"> كمية المنتج   <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input  type="number"  name="quantity" id="quantity" value="<?php echo e($products->quantity); ?>" class="form-control col-md-7 col-xs-12" required>
                        </div>
                      </div>
                      
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="price"> سعر القطعه الواحده  <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input  type="number"  name="price_unit" id="price_unit" value="<?php echo e($products->price_unit); ?>" class="form-control col-md-7 col-xs-12" required>
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"> سعر المنتج قبل الخصم 
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input  type="number"  name="discount" id="discount" value="<?php echo e($products->discount); ?>" class="form-control col-md-7 col-xs-12" >
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="price"> سعر المنتج بعد الخصم <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input  type="number"  name="price" id="price" value="<?php echo e($products->price); ?>" class="form-control col-md-7 col-xs-12" required>
                        </div>
                      </div>
                      
                     
                      
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="description"> تفاصيل    <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <textarea name="description" id="description" class="form-control col-md-7 col-xs-12" ><?php echo e($products->description); ?></textarea>
                        </div>
                      </div>
                      
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="title" requied>تفعيل المنتج ؟
                        </label>
                        <?php if($products->status == 1): ?>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <input type="radio" name="status" value="1" checked> نعم<br>
                            <input type="radio" name="status" value="0"> لا<br>
                        </div>
                        <?php elseif($products->status == 0): ?>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="radio" name="status" value="1" > نعم<br>
                          <input type="radio" name="status" value="0" checked> لا<br>
                      </div>
                      <?php endif; ?>
                    </div>

                    <div class="form-group">
                      <label class="control-label col-md-3 col-sm-3 col-xs-12" for="title" requied>تحديد كميه للمنتج ؟ 
                      </label>
                      <?php if($products->quantity_status == 1): ?>
                      <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="radio" name="quantity_status" value="1" checked> نعم<br>
                          <input type="radio" name="quantity_status" value="0"> لا<br>
                      </div>
                      <?php elseif($products->quantity_status == 0): ?>
                      <div class="col-md-6 col-sm-6 col-xs-12">
                        <input type="radio" name="quantity_status" value="1" > نعم<br>
                        <input type="radio" name="quantity_status" value="0" checked> لا<br>
                    </div>
                    <?php endif; ?>
                  </div>
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="title" requied> وضع المنتج في قائمه الانتظار
                        </label>
                        <?php if($products->waiting_status == 1): ?>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <input type="radio" name="waiting_status" value="1" checked> نعم<br>
                            <input type="radio" name="waiting_status" value="0"> لا<br>
                        </div>
                        <?php elseif($products->waiting_status == 0): ?>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="radio" name="waiting_status" value="1" > نعم<br>
                          <input type="radio" name="waiting_status" value="0" checked> لا<br>
                      </div>
                      <?php endif; ?>
                    </div>

                    <div class="form-group">
                      <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"> الحد الاقصي للكميه   <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 col-xs-12">
                        <input  type="number"  name="max_quantity" id="max_quantity" value="<?php echo e($products->max_quantity); ?>" class="form-control col-md-7 col-xs-12" required>
                      </div>
                    </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" >صورة</label>
                        <div class="input-group" >
                        <div class="col-md-6 col-sm-6 col-xs-12">
                              <input type="file" name="image" id="images" class="form-control" >
                             </div>
                             <img src="<?php echo e(asset('uploads/products/'.$products->image)); ?>"  alt="Image" style="width:50px;height:50px;margin-left:320px;">  

                          </div>
                        </div>
                     
    
              <div class="ln_solid"></div>
              <div class="form-group">
                <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                  <button class="btn btn-primary" type="button"><a href="<?php echo e(url('/')); ?>/admin/products" style="color:white">إلغاء</a></button>
                  <button class="btn btn-primary" type="reset">إعاده</button>
                  <button type="submit" class="btn btn-success">تعديل</button>
                
                </div>
              </div>
              
              </form>
                  </div>
                </div>
              </div>
              </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/vfffgsmy/public_html/control/resources/views/admin/products/edit.blade.php ENDPATH**/ ?>