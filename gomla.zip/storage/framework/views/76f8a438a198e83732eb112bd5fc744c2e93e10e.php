<?php $__env->startSection('content'); ?>


      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_panel">
            <div class="x_title">
              <h2>اضافه طالب</h2>
              <ul class="nav navbar-right panel_toolbox">
                <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                </li>
                
                </ul>
              <div class="clearfix"></div>
          </div>
      <div class="x_content">
        <br>
        <form method="POST" action="<?php echo e(Route('students.store')); ?>" enctype="multipart/form-data" data-parsley-validate="" class="form-horizontal form-label-left">

          <?php echo e(csrf_field()); ?>



        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"> الاسم الاول <span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input  type="text"  name="first_name" id="first_name" value="<?php echo e(old('first_name')); ?>" class="form-control col-md-7 col-xs-12" required>
          </div>
        </div>
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"> الاسم الثاني <span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input  type="text"  name="middle_name" id="middle_name" value="<?php echo e(old('middle_name')); ?>" class="form-control col-md-7 col-xs-12" required>
          </div>
        </div>
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"> الاسم الاخير <span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input  type="text"  name="last_name" id="last_name" value="<?php echo e(old('last_name')); ?>" class="form-control col-md-7 col-xs-12" required>
          </div>
        </div>
        
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="email">اسم المستخدم<span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" name="username" id="username"  value="<?php echo e(old('username')); ?>" required="required" class="form-control col-md-7 col-xs-12">
          </div>
        </div>

          
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="password">الرقم السري<span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="password" name="password" id="password" required="required" class="form-control col-md-7 col-xs-12">
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="grade_id"> المرحله الدراسيه
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <select class="form-control col-md-7 col-xs-12" name="grade_id">
                <option value="">---</option>
              <?php $__currentLoopData = $grads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($grad->id); ?>"><?php echo e($grad->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </select>
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="year_id"> السنه الدراسيه
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <select class="form-control col-md-7 col-xs-12" name="year_id">
                <option value="">---</option>
              <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($year->id); ?>"><?php echo e($year->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </select>
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="subject_id"> الماده الدراسيه
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <select class="form-control col-md-7 col-xs-12" name="subject_id">
                <option value="">---</option>
              <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($subject->id); ?>"><?php echo e($subject->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </select>
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="study_fee"> الباقه الدراسيه
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <select class="form-control col-md-7 col-xs-12" name="study_fee">
                <option value="">---</option>
                <option value="subject">ماده</option>
                <option value="chapter">فصل</option>
                <option value="lesson">شابتر</option>
               
            </select>
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" >صوره الطالب </label>
          <div class="input-group" >
          <div class="col-md-6 col-sm-6 col-xs-12" >
              <input type="file" name="student_image" id="student_image" class="form-control"> </div>
          </div>
        </div>

        <div class="ln_solid"></div>
         <div class="form-group">
          <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
            <button class="btn btn-primary" type="button"><a href="<?php echo e(url('/')); ?>/admin/students" style="color:white">إلغاء</a></button>
            <button class="btn btn-primary" type="reset">إعاده</button>
            <button type="submit" class="btn btn-success"><a href="<?php echo e(url('/')); ?>/admin/students" style="color:white">اضافه</a></button>
          </div>
        </div>

          </form>
        </div>
      </div>
        </div>
      </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\EddGo\resources\views/admin/students/create.blade.php ENDPATH**/ ?>