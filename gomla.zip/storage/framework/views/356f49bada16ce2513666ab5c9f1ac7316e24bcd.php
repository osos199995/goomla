<?php $__env->startSection('content'); ?>


<div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_panel">
            <div class="x_title">
              <h2>تعديل  المدرس </h2>
              <ul class="nav navbar-right panel_toolbox">
                <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                </li>
                
        </ul>
        <div class="clearfix"></div>
      </div>
      <div class="x_content">
        <br>
        <form method="POST" action="<?php echo e(url('admin/teachers/'.$teachers->id)); ?>" enctype="multipart/form-data" teachers-parsley-validate="" class="form-horizontal form-label-left" >
        
        <input name="_method" type="hidden" value="PUT">
            <?php echo e(csrf_field()); ?>

      
            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">اسم الماده
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input type="text" id="name" name="name" value="<?php echo e($teachers->name); ?>" class="form-control col-md-7 col-xs-12" required>
                </div>
              </div>

              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">اسم المستخدم
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input type="text" id="username" name="username" value="<?php echo e($teachers->username); ?>" class="form-control col-md-7 col-xs-12" required>
                </div>
              </div>

              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">الرقم السري
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input type="password" id="password" name="password" value="<?php echo e($teachers->password); ?>" class="form-control col-md-7 col-xs-12" required>
                </div>
              </div>

              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="description">وصف الماده
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <textarea  name="description" id="description"  class="form-control col-md-7 col-xs-12"><?php echo e($teachers->description); ?>

                  </textarea>
                </div>
              </div>

            <div class="form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="grade_id">المرحله الدراسيه
              </label>
              <div class="col-md-6 col-sm-6 col-xs-12">
                <select class="form-control col-md-7 col-xs-12" name="grade_id">
                    <option value="">---</option>
                  <?php $__currentLoopData = $grads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($grad->id); ?>" <?php echo e(($grad->id == $teachers->grade_id)?"selected":""); ?>><?php echo e($grad->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </select>
              </div>
            </div> 

            <div class="form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="year_id">المرحله الدراسيه
              </label>
              <div class="col-md-6 col-sm-6 col-xs-12">
                <select class="form-control col-md-7 col-xs-12" name="year_id">
                    <option value="">---</option>
                  <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($year->id); ?>" <?php echo e(($year->id == $teachers->year_id)?"selected":""); ?>><?php echo e($year->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </select>
              </div>
            </div> 

            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="year_id">الماده الدراسيه
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <select class="form-control col-md-7 col-xs-12" name="subject_id">
                      <option value="">---</option>
                    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($subject->id); ?>" <?php echo e(($subject->id == $teachers->subject_id)?"selected":""); ?>><?php echo e($subject->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                  </select>
                </div>
              </div>

            
            <div class="form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-12" >صوره الماده </label>
              <div class="input-group" > 
              <div class="col-md-6 col-sm-6 col-xs-12" >
                  <input type="file" name="teacher_image"  value="<?php echo e($teachers->teacher_image); ?>" id="teacher_image" class="form-control"> </div>
              </div>
              <?php if($teachers->teacher_image ==null): ?>
              <?php else: ?>
              <img src="<?php echo e(asset('uploads/teachers/'.$teachers->teacher_image)); ?>"  alt="Image" style="width:50px;height:50px;margin-left:30px;">
              <?php endif; ?>
            </div>


              <div class="ln_solid"></div>
              <div class="form-group">
                <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                  <button class="btn btn-primary" type="button"><a href="<?php echo e(url('/')); ?>/admin/teachers" style="color:white">إلغاء</a></button>
                  <button class="btn btn-primary" type="reset">ارسال</button>
                  <button type="submit" class="btn btn-success">تعديل</button>
                
                </div>
              </div>
              
              </form>
                  </div>
                </div>
              </div>
              </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\EddGo\resources\views/admin/teachers/edit.blade.php ENDPATH**/ ?>