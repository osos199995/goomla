
<?php $__env->startSection('content'); ?>


<div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_panel">
            <div class="x_title">
              <h2>تعديل المديونيه</h2>
              <ul class="nav navbar-right panel_toolbox">
                <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                </li>
                
        </ul>
        <div class="clearfix"></div>
      </div>
      <div class="x_content">
        <br>
        <form method="POST" action="<?php echo e(url('admin/depts/'.$depts->id)); ?>" enctype="multipart/form-data" categories-parsley-validate="" class="form-horizontal form-label-left" >
        
        <input name="_method" type="hidden" value="PUT">
            <?php echo e(csrf_field()); ?>

          
            
                      <div class="form-group">
                        
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input  type="hidden"  name="user_id" id="user_id" value="<?php echo e($depts->user_id); ?>" class="form-control col-md-7 col-xs-12" required>
                        </div>
                      </div>
                      
                     
                    <input  type="hidden"  name="order_id" id="order_id" value="<?php echo e($depts->order_id); ?>" class="form-control col-md-7 col-xs-12" >
                        

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"> الإجمالي 
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input  type="hidden"  name="total" id="total" value="<?php echo e($depts->total); ?>" class="form-control col-md-7 col-xs-12" >
                          <label  type="number"  name="total" id="total" value="<?php echo e($depts->total); ?>" class="form-control col-md-7 col-xs-12" ><?php echo e($depts->total); ?></label>
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="paid"> المبلغ المدفوع <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input  type="number"  name="paid" id="paid" value="<?php echo e($depts->paid); ?>" class="form-control col-md-7 col-xs-12" required>
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="discount"> التاريخ <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input  type="text"  name="date" id="date" value="<?php echo e($depts->date); ?>" class="form-control col-md-7 col-xs-12" required>
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="discount"> الخصم <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input  type="number"  name="discount" id="discount" value="<?php echo e($depts->discount); ?>" class="form-control col-md-7 col-xs-12" required>
                        </div>
                      </div>
                      
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="paytype"> طريقه الدفع <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input  type="text"  name="paytype" id="paytype" value="<?php echo e($depts->paytype); ?>" class="form-control col-md-7 col-xs-12" required>
                        </div>
                      </div>
                       
    
              <div class="ln_solid"></div>
              <div class="form-group">
                <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                  <button class="btn btn-primary" type="button"><a href="<?php echo e(url('/')); ?>/admin/depts" style="color:white">إلغاء</a></button>
                  <button class="btn btn-primary" type="reset">اعاده</button>
                  <button type="submit" class="btn btn-success">تعديل</button>
                
                </div>
              </div>
              
              </form>
                  </div>
                </div>
              </div>
              </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/vfffgsmy/public_html/control/resources/views/admin/depts/edit.blade.php ENDPATH**/ ?>