
<?php $__env->startSection('content'); ?>


<div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_panel">
            <div class="x_title">
              <h2>تعديل مسار الطلب </h2>
              <ul class="nav navbar-right panel_toolbox">
                <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                </li>
                
        </ul>
        <div class="clearfix"></div>
      </div>
      <div class="x_content">
        <br>
        <form method="POST" action="<?php echo e(url('admin/orders/'.$orders->order_id . '/track')); ?>" enctype="multipart/form-data" orders-parsley-validate="" class="form-horizontal form-label-left" >
        
        
            <?php echo e(csrf_field()); ?>

      
               
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="title" requied>مسار الاوردر
                        </label>
                        
                        <div class="col-md-6 col-sm-6 col-xs-12" style="font-size: 15px;">
                            <input type="radio" name="stage_id" value="0" <?php if($orders->stage_id == 0): ?> checked <?php endif; ?>> معلق<br>
                            <br>
                            <input type="radio" name="stage_id" value="1" <?php if($orders->stage_id == 1): ?> checked <?php endif; ?>> جاري المعالجه<br>
                            <br>
                            
                            <input type="radio" name="stage_id" value="2" <?php if($orders->stage_id == 2): ?> checked <?php endif; ?>> تم التأكيد<br>
                            <br>
                            
                            <input type="radio" name="stage_id" value="3" <?php if($orders->stage_id == 3): ?> checked <?php endif; ?>> جاري التحضير<br>
                            <br>
                            
                            <input type="radio" name="stage_id" value="4" <?php if($orders->stage_id == 4): ?> checked <?php endif; ?>> في الطريق<br>
                            <br>
                            
                            <input type="radio" name="stage_id" value="5" <?php if($orders->stage_id == 5): ?> checked <?php endif; ?>> تم التسليم<br>


                        </div>
                       
                    </div>
    
              <div class="ln_solid"></div>
              <div class="form-group">
                <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                  <button class="btn btn-primary" type="button"><a href="<?php echo e(url('/')); ?>/admin/orders" style="color:white">إلغاء</a></button>
                  <button class="btn btn-primary" type="reset">ارسال</button>
                  <button type="submit" class="btn btn-success">تعديل</button>
                
                </div>
              </div>
              
              </form>
                  </div>
                </div>
              </div>
              </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mostafa/meeza.innovations-eg.com/resources/views/admin/orders/track.blade.php ENDPATH**/ ?>