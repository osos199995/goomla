<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use Hash;

class users extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (true) {
            return User::all();
        }
    }

   

    public function store(Request $request)
    {
        return User::create([
            'id' => $request['id'],
            'name' => $request['name'],
            'email' => $request['email'],
            'image' => $request['image'],
            'role' => 'user',
            'password' => Hash::make($request['password']),
            'shop_name' => $request['shop_name'],
            'shop_type' => $request['shop_type'],
            'area' => $request['area'],
            'address' => $request['address'],
            'location' => $request['location'],

        ]);
    }

  
    public function show($id)
    {
        if (true) {
            return User::find($id);
        }
    }

    public function search(Request $request){

        if ($search = $request->name) {
            $users = User::where(function($query) use ($search){
                $query->where('name','LIKE',"%$search%");
            })->first();
        }else{
            $users = User::latest()->paginate(5);
        }

        return $users;

    }

   
    public function update(Request $request)
    {
        $users = User::findOrFail($request->id);
    
        
        $users->save();
        $id= $users->id;

        if($image = $request->file('image')){
            $destinationPath = 'uploads/users'; 
            $extension = $image->getClientOriginalExtension(); 
            $fileName = $id.'_image'.'.'.$extension; 
            
            $image->move($destinationPath, $fileName); 
            
            User::where('id',$id)->update(['image' => $fileName]); 
        }
}

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
