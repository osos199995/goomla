<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Store;
use Hash;

class stores extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (true) {
            return Store::all();
        }
    }

   

    public function store(Request $request)
    {
        return Store::create([
            'name' => $request['name'],
            'section' => $request['section'],
            'address' => $request['address'],

        ]);
    }

  
    public function show($id)
    {
       
    }

    
   
    public function update(Request $request)
    {
      
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
