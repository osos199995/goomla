<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Company_subcategory extends Model
{
    //
}
