<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Min_price extends Model
{
    protected $fillable = [
        'price' ,
   ];
}
